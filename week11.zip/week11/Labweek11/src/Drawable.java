public interface Drawable {
    public void drawable();
}
